package com.aviva.camel;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class MyProcessor implements Processor {

	public void process(Exchange exchange) throws Exception {
		
			Order order = new Order(1);
			order.addItem("Coke", 20, 2);
			order.addItem("Banana", 12, 1);
			order.addItem("Tab", 5, 250);
			exchange.getIn().setBody(order);
	
		
	}

}
