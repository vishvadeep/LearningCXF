package com.aviva.camel;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

public class MyRouterBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		

		from("timer://generateOrders?fixedRate=true&period=10000")
				.log("Generate order items")
				.process(new MyProcessor()).to("direct:processOrder");

		from("direct:processOrder").log("Process order ${body}")
				.split(simple("${body.items}"))
				.to("direct:processOrderItem")
				.log("Processing done ${body}").end()
				.log("Order processed: ${body}");

		from("direct:processOrderItem").log(
				"Processing item ${body.itemName}").to(
				"bean:processOrderItem");

	
	}

}
