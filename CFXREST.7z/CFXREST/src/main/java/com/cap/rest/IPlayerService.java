package com.cap.rest;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

@Path("/player")
public interface IPlayerService {

	// http://localhost:8080/ApacheCXF-QueryParam/services/player/welcome?name=Gilchrist
	@GET
	@Path("/welcome")
	public Response welcomePlayer(@QueryParam("name") String playerName);

	// http://localhost:8080/ApacheCXF-QueryParam/services/player/playerinfo?name=Pietersen&age=33&matches=104
	@GET
	@Path("/playerinfo")
	public Response getPlayerInfo(
			@QueryParam("name") String playerName, 
			@QueryParam("age") int age, 
			@QueryParam("matches") int matches);
	
	@POST
	@Path("/insert")
	public Response insert(@FormParam("name") String name ,@FormParam("pass") String pass,@Context HttpServletRequest request,@Context HttpServletResponse response) throws IOException;

	
	@POST
	@Path("/update")
	public Response update(@FormParam("name") String name ,@FormParam("pass") String pass);

	
	@POST
	@Path("/delete")
	public Response delete(@FormParam("name") String ame ,@FormParam("pass") String pass);

	
}