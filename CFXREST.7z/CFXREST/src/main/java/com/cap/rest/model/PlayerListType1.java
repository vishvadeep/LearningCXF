package com.cap.rest.model;

import java.util.ArrayList;
import java.util.List;

public class PlayerListType1 {

	List<PlayerType1> playerType = new ArrayList<>();

	public List<PlayerType1> getPlayerType() {
		return playerType;
	}

	public void setPlayerType(List<PlayerType1> playerType) {
		this.playerType = playerType;
	}
	
}
