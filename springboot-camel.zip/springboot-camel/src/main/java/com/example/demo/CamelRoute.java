package com.example.demo;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class CamelRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception{
		from("direct:firstRoute").log("camel Body :"+" i am in camel session");
	}
}
