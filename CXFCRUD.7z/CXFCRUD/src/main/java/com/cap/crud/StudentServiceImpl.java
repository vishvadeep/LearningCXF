package com.cap.crud;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cap.crud.Dao.StudentDAO;
import com.cap.crud.Model.Student;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("studentservices")
public class StudentServiceImpl implements IStudentService{


	 @SuppressWarnings("unchecked")
	    @Transactional
	   
	    public String getAllStudentInfo() {
		 
		 return "string";
	 }
	 
	 @GET	
		@Consumes({MediaType.APPLICATION_JSON})
		@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
		@Path("{studentId}")
		public Student getStudentDetails(@PathParam("studentId") String studentId) {
			
			StudentDAO studentDao = new StudentDAO();
		       Student student = null;
		       try {
		            student = studentDao.getStudentDetails(studentId);
		       } catch (SQLException e) {
		           e.printStackTrace();
		       }

		       return student;
		}
	 

}
