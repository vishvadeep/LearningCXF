package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Book;
import com.example.demo.repository.BookRepository;

@RestController
@RequestMapping("/api")
public class BookController {

	@Autowired
	BookRepository bookRepository; 
	
	// Get All Notes
	@GetMapping("/books")
	public List<Book> getAllBooks() {
	    return bookRepository.findAll();
	}
	
	// Get All Notes
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable(value ="id") int id) {
	    Book b = bookRepository.findOne(id);
	    if (b==null){
	    	return  ResponseEntity.notFound().build();
	    }
	    	
	    return ResponseEntity.ok().body(b);
	    
	}
	
	
	@PostMapping("/books")
	public Book createBook(@Valid @RequestBody Book book){
		return bookRepository.save(book);
	}
	
	@PutMapping("/books/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable (value="id") int id, @Valid @RequestBody Book bookDetail){
		
		Book book = bookRepository.findOne(id);
		if (book==null){
			return ResponseEntity.notFound().build();
		}
		
		book.setDescription(bookDetail.getDescription());
		book.setTitle(bookDetail.getTitle());
		Book updateBook = bookRepository.save(book);
		return ResponseEntity.ok(updateBook);
	}
	
	@DeleteMapping("/books/{id}")
	public ResponseEntity<Book> deleteBook(@PathVariable(value="id") int id){
		
		Book b = bookRepository.findOne(id);
		
		if (b==null){
			return ResponseEntity.notFound().build();
		}
		bookRepository.delete(b);
		
		
		return ResponseEntity.ok().build();
	}
}
