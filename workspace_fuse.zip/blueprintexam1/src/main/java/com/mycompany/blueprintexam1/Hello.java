package com.mycompany.blueprintexam1;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
