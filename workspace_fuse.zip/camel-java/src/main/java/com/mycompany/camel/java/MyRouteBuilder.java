package com.mycompany.camel.java;

import org.apache.camel.builder.RouteBuilder;

public class MyRouteBuilder  extends RouteBuilder  {

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		
		from("file:D:/inputFolder?noop=true").to("file:D:/outputFolder");
		
	}

	

}
