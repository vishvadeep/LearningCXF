package com.pack.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.file.GenericFileFilter;
import org.apache.abdera.model.Entry;

public class FilterJson<T> implements GenericFileFilter<T>{


	
	
		
	


	@Override
	public boolean accept(GenericFile<T> file) {
		// TODO Auto-generated method stub
		 if (file.isDirectory()) {
	            return true;
	        }
	        // we dont accept any files starting with skip in the name
	        return file.getFileName().endsWith("xml");
	   
	}

	public boolean filter(Exchange exchange){
		Message ms = exchange.getIn();

		String filename = ms.toString();
			if (filename.endsWith("xml")){
				return true;
			}else 
			{
				return false;
			}


			}
	
}
