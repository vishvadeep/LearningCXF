package com.pack.processor;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		
	
	
		AbstractApplicationContext ctx = new 
				ClassPathXmlApplicationContext("applicationContext-camel.xml");
		
		ctx.start();
		System.out.println("context has been started");
		
try {
	Thread.sleep(10000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
ctx.start();
ctx.close();
		
	}
}
