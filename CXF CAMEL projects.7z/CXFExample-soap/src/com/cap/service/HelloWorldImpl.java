package com.cap.service;

import javax.jws.WebService;

@WebService
public class HelloWorldImpl implements HelloWorld {
	public String sayHi(String name) {
		System.out.println("say hello to " + name);
		return "Hello " + name + "!";
	}
}