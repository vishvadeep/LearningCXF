package com.cap.service;

import java.util.List;
import com.cap.service.Product;

import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public interface  ProductService {

	
	List<Product> getProducts();



   void addProduct(@WebParam(name = "product") Product product);


     public void addProducts(@WebParam(name = "products") List<Product> products);
}
