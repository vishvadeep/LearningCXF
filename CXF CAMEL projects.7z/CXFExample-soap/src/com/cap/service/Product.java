package com.cap.service;

public class Product {

	private String itemName;

   private String category;

   private double price;

   private String details;

   
   public Product() {
	// TODO Auto-generated constructor stub
}
   
   public Product(String itemName, String category, double price,

	            String details) {

	         this.itemName = itemName;

      this.category = category;

         this.price = price;

        this.details = details;

     }
   
public String getItemName() {
	return itemName;
}

public void setItemName(String itemName) {
	this.itemName = itemName;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}
//@IgnoreProperty
public String getDetails() {
	return details;
}

public void setDetails(String details) {
	this.details = details;
}
   
   
}
