package com.cap.service;


 import java.util.ArrayList;

 import java.util.List;
 import com.cap.service.Product;
  

import javax.jws.WebParam;

import javax.jws.WebService;

@WebService
public class ProductServiceImpl implements ProductService{

	
	public List<Product> getProducts() {

         List<Product> products = new ArrayList<Product>();

         products.add(new Product("SpringInAction", "Manning", 200,

               "Book about Spring"));

         products.add(new Product("EJB3InAction", "Manning", 200,

                 "Book about EJB3"));

         return products;

     }

  

   public void addProduct(Product product) {

         System.out.println(product);

     }

  

     public void addProducts(@WebParam(name = "products") List<Product> products) {

         for (Product product : products) {

           System.out.println(product);

         }

		     }
}
