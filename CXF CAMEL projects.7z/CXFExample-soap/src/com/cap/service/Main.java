package com.cap.service;

import org.apache.cxf.jaxws.JaxWsServerFactoryBean;

public class Main {

	
	public static void main(String[] args) {
		HelloWorld helloWorld = new HelloWorldImpl();

		JaxWsServerFactoryBean factory = new JaxWsServerFactoryBean();
		factory.setServiceClass(HelloWorld.class);
		factory.setAddress("http://localhost:9901/HelloWorld");
		factory.setServiceBean(helloWorld);
		factory.create();

		System.out.println("Server ready...");

	}
}
