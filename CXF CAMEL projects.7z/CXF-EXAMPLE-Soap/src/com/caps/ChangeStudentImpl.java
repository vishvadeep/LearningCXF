package com.caps;

import java.util.List;

import javax.jws.WebService;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.headers.Header;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.PhaseInterceptor;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.w3c.dom.Element;

@WebService(endpointInterface = "com.caps.ChangeStudent")
public class ChangeStudentImpl implements ChangeStudent {

	@Override
	public Student changeStudentNameName(Student student) {
		// TODO Auto-generated method stub
		
		
			
			
			
				Message message = PhaseInterceptorChain.getCurrentMessage();

			        SoapMessage soapMessage = (SoapMessage) message;
			        List<Header> list = soapMessage.getHeaders();
			        for (Header header : list) {
			            System.out.println("Country: "+((Element)header.getObject()).getTextContent());
			        }
				student.setName("Hello " + student.getName());
				return student;
			}
	}

	


