package com.caps;

import javax.jws.WebService;

@WebService
public interface ChangeStudent {

Student  changeStudentNameName(Student student);
}
