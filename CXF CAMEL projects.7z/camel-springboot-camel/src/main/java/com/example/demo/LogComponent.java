package com.example.demo;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.main.Main;

public class LogComponent {

	public static void main(String[] args) throws Exception {
		Main main = new Main();
		main.enableHangupSupport();
		
		main.addRouteBuilder(new RouteLogger());
	//	main.addRouteBuilder(new RouteLogger());
		main.run(args);
		
	}
	

}
  class RouteLogger  extends RouteBuilder {

	public RouteLogger(){
		
	}
	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		from("timer://simpleTimer?period=1000").setBody(simple ("hello from  timer")).to
		("log:myLog?level=info");
	
	}
	
}
