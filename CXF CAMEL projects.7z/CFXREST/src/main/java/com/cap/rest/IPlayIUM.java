package com.cap.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cap.rest.model.PlayerType;

@Path("/playerIUD")
public interface IPlayIUM {

	 	@POST
	    @Path("Insert")
	    @Consumes({MediaType.APPLICATION_FORM_URLENCODED})
	    @Produces({/*MediaType.APPLICATION_XML,*/ MediaType.APPLICATION_JSON})
	    public String insertPlayerInfo(@FormParam("name") String name,@FormParam("pass") String pass);

	 	@POST
	    @Path("Update")
	    @Consumes({MediaType.APPLICATION_FORM_URLENCODED})
	    @Produces({/*MediaType.APPLICATION_XML,*/ MediaType.APPLICATION_JSON})
	    public String updatePlayerInfo(@FormParam("name") String name,@FormParam("pass") String pass);

	 	@POST
	    @Path("delete")
	    @Consumes({MediaType.APPLICATION_FORM_URLENCODED})
	    @Produces({/*MediaType.APPLICATION_XML,*/ MediaType.APPLICATION_JSON})
	    public String deletePlayerInfo(@FormParam("name") String name,@FormParam("pass") String pass);

	 
}
