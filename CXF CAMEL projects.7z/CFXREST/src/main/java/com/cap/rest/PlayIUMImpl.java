package com.cap.rest;

import org.springframework.stereotype.Service;

import com.cap.rest.model.PlayerType;

@Service("playerService2")
public class PlayIUMImpl implements IPlayIUM {

	@Override
	public String insertPlayerInfo(String name,String pass) {
		// TODO Auto-generated method stub
	System.out.println("insert");
		return "insert name ="+name+" pass = pass";
	}

	@Override
	public String updatePlayerInfo(String name,String pass) {
		// TODO Auto-generated method stub
		System.out.println("update");
		return "update name ="+name+" pass = pass";
	}

	@Override
	public String deletePlayerInfo(String name,String pass) {
		// TODO Auto-generated method stub
		System.out.println("delete");
		return "delete name ="+name+" pass ="+ pass;
	}

}
